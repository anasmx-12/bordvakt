# Bordvakt – mjukvaran som körs i restaurangen

Läser restaurangens IP-kameror, avgör med AI vilka bord som har gäster, om personal varit vid bordet och om disk står kvar, och skickar larm till personalens mobiler. Personalens app (samma som demon på hemsidan) går i **liveläge** mot den här datorn.

**Integritet:** bilderna finns bara i minnet under analysen och sparas aldrig. Ingen ansiktsigenkänning. Databasen innehåller bara bordshändelser och tider (raderas efter 90 dagar).

## Hårdvara
En liten dator i restaurangens nätverk, t.ex. en mini-PC med Intel N100 (16 GB RAM) eller bättre. Den klarar 2–4 kameror med modellen `yolov8n.pt` i 2 analyser/sekund. Fler kameror: snabbare dator eller NVIDIA Jetson.

## Installation (Ubuntu/Debian)
```bash
sudo apt install -y python3-venv
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt
cp config.example.yaml config.yaml   # fyll i namn, PIN, kameror, bord och ntfy-ämne
python -m bordvakt.main --config config.yaml
```
Första gången laddas AI-modellen ned automatiskt (cirka 6 MB).

## Kom igång hos en restaurang
1. Skapa ett användarkonto i kamerasystemet med bara läsrätt och använd **understreamen** (lägre upplösning räcker).
2. Lägg in kamerornas RTSP-adresser och borden i `config.yaml`.
3. Starta Bordvakt, öppna `http://<datorns-ip>:8080` i mobilen och logga in med PIN.
4. Gå till `http://<datorns-ip>:8080/setup` och rita in varje bord **med stolarna** på kamerabilden. Spara.
5. Personalen installerar appen **ntfy** och prenumererar på ämnet från `config.yaml`.
6. Testa: sätt dig vid ett bord – efter 20 s blir det upptaget, efter 5 min utan personal kommer larmet.

## Finjustering
- `standing_ratio`: höj om sittande gäster räknas som personal, sänk om personal missas.
- `staff_colour_hsv`: om personalen har enhetlig klädfärg blir det säkrare.
- Personalen kan alltid trycka "Jag tar det" i appen – det räknas som besök.

## Kör som tjänst (startar automatiskt)
```ini
# /etc/systemd/system/bordvakt.service
[Unit]
Description=Bordvakt
After=network-online.target
[Service]
WorkingDirectory=/opt/bordvakt-edge
ExecStart=/opt/bordvakt-edge/venv/bin/python -m bordvakt.main --config config.yaml
Restart=always
[Install]
WantedBy=multi-user.target
```
`sudo systemctl enable --now bordvakt`

## Tester
`pip install pytest && python -m pytest tests`
