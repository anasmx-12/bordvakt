"""Push-notiser till personalens mobiler via ntfy (gratis app för iPhone och Android)."""
from __future__ import annotations

import logging
import queue
import threading

import httpx

log = logging.getLogger("bordvakt.notify")

TITLES = {"waiter": ("{name} behöver servitör", "bell", 4),
          "checkin": ("Kolla {name}", "receipt", 3),
          "cleaning": ("Städa {name}", "sponge", 3)}


class Notifier:
    def __init__(self, server: str = "https://ntfy.sh", topic: str | None = None, token: str | None = None):
        self.url = server.rstrip("/") if topic else None
        self.topic = topic
        self.token = token
        self.q: "queue.Queue[dict]" = queue.Queue(maxsize=200)
        threading.Thread(target=self._run, daemon=True, name="ntfy").start()

    def send(self, e: dict):
        if self.url and e.get("type") == "alert":
            try:
                self.q.put_nowait(e)
            except queue.Full:
                pass

    def _run(self):
        with httpx.Client(timeout=10) as c:
            while True:
                e = self.q.get()
                title, tag, prio = TITLES.get(e.get("kind"), ("Bordvakt", "bell", 3))
                body = {"topic": self.topic, "title": title.format(name=e["name"]), "message": e["text"],
                        "tags": [tag], "priority": prio}
                headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
                try:
                    c.post(self.url, json=body, headers=headers)
                except Exception as ex:  # nätet nere: larmet syns ändå i appen på wifi
                    log.warning("Kunde inte skicka push: %s", ex)
