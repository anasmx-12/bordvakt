"""Kameror och AI-detektering.

Bilderna finns bara i minnet medan de analyseras. Inget sparas på disk och inget skickas
ut från restaurangens nätverk. Ut från den här modulen går bara siffror per bord.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

import cv2
import numpy as np

from .tracker import Obs

log = logging.getLogger("bordvakt.vision")

# COCO-klasser i YOLO: person + saker som brukar stå kvar på ett bord som inte är dukat av
PERSON = 0
DISH_CLASSES = {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55}


class Camera:
    """Läser en RTSP-ström (eller en videofil vid test) i en egen tråd. Behåller bara senaste bilden."""

    def __init__(self, cam_id: str, url: str):
        self.id, self.url = cam_id, url
        self._frame: Optional[np.ndarray] = None
        self._ts = 0.0
        self._lock = threading.Lock()
        self._stop = False
        self.thread = threading.Thread(target=self._run, daemon=True, name=f"cam-{cam_id}")

    def start(self):
        self.thread.start()
        return self

    def stop(self):
        self._stop = True

    @property
    def ok(self) -> bool:
        return time.time() - self._ts < 10

    def latest(self) -> tuple[Optional[np.ndarray], float]:
        with self._lock:
            return self._frame, self._ts

    def _run(self):
        while not self._stop:
            cap = cv2.VideoCapture(self.url)
            if not cap.isOpened():
                log.warning("Kamera %s: kan inte ansluta, försöker igen om 5 s", self.id)
                time.sleep(5)
                continue
            log.info("Kamera %s ansluten", self.id)
            is_file = not str(self.url).lower().startswith(("rtsp", "http"))
            fps = cap.get(cv2.CAP_PROP_FPS) or 25
            while not self._stop:
                ok, frame = cap.read()
                if not ok:
                    if is_file:  # testvideo: börja om
                        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        continue
                    log.warning("Kamera %s: tappade strömmen", self.id)
                    break
                with self._lock:
                    self._frame, self._ts = frame, time.time()
                if is_file:
                    time.sleep(1 / fps)
            cap.release()
            time.sleep(2)


def _inside(poly: np.ndarray, x: float, y: float) -> bool:
    return cv2.pointPolygonTest(poly, (float(x), float(y)), False) >= 0


class Detector:
    """YOLO-detektering + regler för att avgöra gäst, personal och disk per bordszon."""

    def __init__(self, model: str = "yolov8n.pt", conf: float = 0.35, standing_ratio: float = 1.9,
                 staff_hsv: Optional[dict] = None, imgsz: int = 640):
        from ultralytics import YOLO  # importeras här så att tester kan köras utan modellen
        self.model = YOLO(model)
        self.conf, self.standing_ratio, self.imgsz = conf, standing_ratio, imgsz
        self.staff_hsv = staff_hsv  # t.ex. {"lower": [0,0,0], "upper": [180,255,60], "min_share": 0.35} för svart klädsel

    def detect(self, frame: np.ndarray) -> list[tuple[int, float, float, float, float]]:
        res = self.model.predict(frame, conf=self.conf, imgsz=self.imgsz, verbose=False)[0]
        out = []
        for b in res.boxes:
            c = int(b.cls[0])
            if c == PERSON or c in DISH_CLASSES:
                x1, y1, x2, y2 = (float(v) for v in b.xyxy[0])
                out.append((c, x1, y1, x2, y2))
        return out

    def _is_staff_colour(self, frame: np.ndarray, x1, y1, x2, y2) -> bool:
        if not self.staff_hsv:
            return False
        h = y2 - y1
        torso = frame[int(y1 + h * 0.25):int(y1 + h * 0.6), int(x1):int(x2)]
        if torso.size == 0:
            return False
        hsv = cv2.cvtColor(torso, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array(self.staff_hsv["lower"]), np.array(self.staff_hsv["upper"]))
        return mask.mean() / 255 >= self.staff_hsv.get("min_share", 0.35)

    def observe_tables(self, frame: np.ndarray, zones: dict[str, list]) -> dict[str, Obs]:
        """zones: bord-id -> polygon i normaliserade koordinater (0–1)."""
        hgt, wid = frame.shape[:2]
        polys = {tid: (np.array(z, dtype=np.float32) * [wid, hgt]).astype(np.float32) for tid, z in zones.items()}
        obs = {tid: Obs() for tid in zones}
        for c, x1, y1, x2, y2 in self.detect(frame):
            cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
            for tid, poly in polys.items():
                if c == PERSON:
                    # sittande: kroppens mitt i zonen. stående: fötterna i zonen.
                    standing = (y2 - y1) / max(1.0, x2 - x1) >= self.standing_ratio
                    px, py = (cx, y2) if standing else (cx, cy + (y2 - y1) * 0.15)
                    if not _inside(poly, px, py):
                        continue
                    if standing or self._is_staff_colour(frame, x1, y1, x2, y2):
                        obs[tid].staff = True
                    else:
                        obs[tid].guests += 1
                elif _inside(poly, cx, cy):
                    obs[tid].dishes = True
        return obs
