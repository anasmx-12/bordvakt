"""Webbserver: appen för personalen, API och WebSocket med bordsstatus i realtid."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import secrets
from pathlib import Path

import cv2
import yaml
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

STATIC = Path(__file__).parent / "static"


def create_app(ctx) -> FastAPI:
    """ctx: objekt med .tracker, .store, .cameras (dict), .cfg (dict), .cfg_path, .lock"""
    app = FastAPI(title="Bordvakt", docs_url=None, redoc_url=None)
    pin = str(ctx.cfg.get("pin") or "")
    secret = secrets.token_bytes(32)
    token = hmac.new(secret, pin.encode(), hashlib.sha256).hexdigest()

    def authed(cookies) -> bool:
        return not pin or hmac.compare_digest(cookies.get("bv", ""), token)

    def deny():
        return JSONResponse({"error": "pin"}, status_code=401)

    def state(party: int = 0):
        cams = [{"id": c.id, "ok": c.ok} for c in ctx.cameras.values()]
        with ctx.lock:
            return ctx.tracker.state(ctx.cfg.get("restaurant", "Restaurang"), cams, party)

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.post("/api/login")
    async def login(req: Request):
        body = await req.json()
        if pin and not hmac.compare_digest(str(body.get("pin", "")), pin):
            await asyncio.sleep(1)
            return deny()
        r = JSONResponse({"ok": True})
        r.set_cookie("bv", token, httponly=True, samesite="lax", max_age=60 * 60 * 24 * 90)
        return r

    @app.get("/api/state")
    def api_state(req: Request, party: int = 0):
        return state(party) if authed(req.cookies) else deny()

    @app.post("/api/tables/{tid}/action")
    async def api_action(tid: str, req: Request):
        if not authed(req.cookies):
            return deny()
        action = (await req.json()).get("action")
        with ctx.lock:
            ok = ctx.tracker.action(tid, action)
        return {"ok": ok}

    @app.get("/api/report")
    def api_report(req: Request, days: int = 7):
        if not authed(req.cookies):
            return deny()
        c = ctx.cfg
        return ctx.store.report(days, len(c["tables"]), int(c.get("tables_per_waiter", 5)),
                                ctx.tracker.rules.waiter_alert_after_s)

    @app.websocket("/ws")
    async def ws(sock: WebSocket):
        await sock.accept()
        if not authed(sock.cookies):
            await sock.close(code=4401)
            return
        party = 0

        async def reader():
            nonlocal party
            while True:
                msg = json.loads(await sock.receive_text())
                party = int(msg.get("party") or 0)

        rt = asyncio.create_task(reader())
        try:
            while True:
                await sock.send_text(json.dumps(state(party)))
                await asyncio.sleep(1)
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            rt.cancel()

    # ------------------------------------------------------------ inställning av bordszoner
    @app.get("/setup")
    def setup(req: Request):
        if not authed(req.cookies):
            return HTMLResponse("<p>Logga in i appen först (öppna / och skriv PIN-koden).</p>", status_code=401)
        return FileResponse(STATIC / "setup.html")

    @app.get("/api/setup/info")
    def setup_info(req: Request):
        if not authed(req.cookies):
            return deny()
        return {"cameras": list(ctx.cameras), "tables": ctx.cfg["tables"]}

    @app.get("/api/setup/snapshot")
    def snapshot(req: Request, cam: str):
        """En stillbild för att rita in borden. Skapas i minnet och sparas inte."""
        if not authed(req.cookies):
            return deny()
        c = ctx.cameras.get(cam)
        frame, _ = c.latest() if c else (None, 0)
        if frame is None:
            return JSONResponse({"error": "ingen bild än"}, status_code=404)
        ok, jpg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        return Response(jpg.tobytes(), media_type="image/jpeg", headers={"Cache-Control": "no-store"})

    @app.post("/api/setup/zones")
    async def save_zones(req: Request):
        if not authed(req.cookies):
            return deny()
        body = await req.json()  # {"table_id": {"camera": "cam1", "zone": [[x,y],...]}}
        with ctx.lock:
            for t in ctx.cfg["tables"]:
                z = body.get(str(t["id"]))
                if z:
                    t["camera"], t["zone"] = z["camera"], z["zone"]
            Path(ctx.cfg_path).write_text(yaml.safe_dump(ctx.cfg, allow_unicode=True, sort_keys=False), encoding="utf-8")
        return {"ok": True}

    return app
