"""Bordsstatus: gör om AI-observationer per bord till status, timers och larm.

Inga bilder hanteras här. In kommer bara siffror per bord och tidpunkt:
hur många gäster som sitter, om personal står vid bordet och om disk står kvar.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class Rules:
    waiter_alert_after_s: int = 300      # larm om ingen servitör varit vid bordet
    waiter_realert_s: int = 180          # nytt larm om ingen kommit efter larmet
    seat_confirm_s: int = 20             # gäster måste sitta så länge innan bordet räknas som upptaget
    leave_confirm_s: int = 60            # bordet måste vara tomt så länge innan gästerna räknas som gått
    staff_visit_s: float = 2.0           # så länge personal måste stå vid bordet för att räknas
    clean_confirm_s: int = 10            # disk borta så länge -> städat
    cleaning_realert_s: int = 240
    checkin_after_seated_s: int = 45 * 60
    checkin_quiet_s: int = 15 * 60
    dining_s: dict = field(default_factory=lambda: {1: 48 * 60, 2: 58 * 60, 3: 72 * 60})
    cleaning_s: int = 4 * 60


@dataclass
class Obs:
    guests: int = 0          # sittande personer i bordets zon
    staff: bool = False      # stående person / personalklädsel vid bordet
    dishes: bool = False     # disk, glas eller flaskor på bordet


def guests_txt(n: int) -> str:
    return f"{n} {'gäst' if n == 1 else 'gäster'}"


def mmss(s: float) -> str:
    s = max(0, int(s))
    return f"{s // 60:02d}:{s % 60:02d}"


def bucket(g: int) -> int:
    return 1 if g <= 2 else 2 if g <= 4 else 3


class Table:
    def __init__(self, cfg: dict, now: float):
        self.id = str(cfg["id"])
        self.name = cfg.get("name", f"Bord {self.id}")
        self.seats = int(cfg.get("seats", 4))
        self.floor = cfg.get("floor", [0, 0])
        self.status = "free"
        self.status_since = now
        self.guests = 0
        self.seated_at: Optional[float] = None
        self.first_waiter_at: Optional[float] = None
        self.last_visit_at: Optional[float] = None
        self.vacated_at: Optional[float] = None
        self.last_alert: Optional[float] = None
        self.checkin_at: Optional[float] = None
        self.checkin_done = False
        # debounce
        self._guests_since: Optional[float] = None
        self._empty_since: Optional[float] = None
        self._staff_since: Optional[float] = None
        self._clean_since: Optional[float] = None
        self._max_guests = 0


class Tracker:
    """Håller alla bord. `emit(event)` anropas för varje händelse (logg + push)."""

    def __init__(self, tables: list[dict], rules: Rules, emit: Callable[[dict], None], clock=time.time):
        self.rules = rules
        self.clock = clock
        self.emit = emit
        now = clock()
        self.tables = {str(t["id"]): Table(t, now) for t in tables}
        self.feed: list[dict] = []
        self._n = 0

    # ------------------------------------------------------------ events
    def _push(self, t: Table, type_: str, text: str, kind: Optional[str] = None, now: Optional[float] = None, **extra):
        now = self.clock() if now is None else now
        self._n += 1
        e = {"ts": now, "table": t.id, "name": t.name, "type": type_, "kind": kind, "text": text,
             "id": f"{t.id}-{type_}-{int(now)}-{self._n}", **extra}
        self.feed.insert(0, e)
        del self.feed[200:]
        self.emit(e)

    def _alert(self, t: Table, kind: str, now: float):
        t.last_alert = now
        if kind == "waiter":
            msg = f"{t.name}: gästerna har väntat {int((now - t.seated_at) // 60)} min utan att en servitör kommit"
        elif kind == "checkin":
            msg = f"{t.name}: ingen har varit vid bordet på {int((now - (t.last_visit_at or t.seated_at)) // 60)} min – kolla om de vill beställa mer eller vill ha notan"
        else:
            msg = f"{t.name} är ledigt men inte städat – gör i ordning för nästa gäster"
        self._push(t, "alert", msg, kind, now)

    # ------------------------------------------------------------ observations
    def observe(self, table_id: str, o: Obs, now: Optional[float] = None):
        now = self.clock() if now is None else now
        t = self.tables.get(str(table_id))
        if not t:
            return
        r = self.rules

        # gäster sitter?
        if o.guests > 0:
            t._empty_since = None
            if t._guests_since is None:
                t._guests_since = now
            t._max_guests = max(t._max_guests, min(o.guests, t.seats))
        else:
            t._guests_since = None
            if t._empty_since is None:
                t._empty_since = now

        if t.status in ("free", "needs_cleaning") and t._guests_since is not None and now - t._guests_since >= r.seat_confirm_s:
            self._seat(t, t._guests_since, t._max_guests or o.guests)

        if t.status == "occupied":
            if o.guests > 0:
                t.guests = max(t.guests, min(o.guests, t.seats))
            # personal vid bordet
            if o.staff:
                if t._staff_since is None:
                    t._staff_since = now
                if now - t._staff_since >= r.staff_visit_s:
                    self._visit(t, now, source="kamera")
            else:
                t._staff_since = None
            if t._empty_since is not None and now - t._empty_since >= r.leave_confirm_s:
                self._leave(t, t._empty_since, dishes=o.dishes)

        if t.status == "needs_cleaning":
            if not o.dishes and o.guests == 0:
                if t._clean_since is None:
                    t._clean_since = now
                if now - t._clean_since >= r.clean_confirm_s:
                    self._cleaned(t, now, "städat och redo")
            else:
                t._clean_since = None

    def tick(self, now: Optional[float] = None):
        """Kör regelbundet (t.ex. varje sekund) för timers och larm."""
        now = self.clock() if now is None else now
        r = self.rules
        for t in self.tables.values():
            if t.status == "occupied":
                if not t.first_waiter_at and now - t.seated_at >= r.waiter_alert_after_s and (
                        not t.last_alert or now - t.last_alert >= r.waiter_realert_s):
                    self._alert(t, "waiter", now)
                if (t.first_waiter_at and not t.checkin_at and now - t.seated_at >= r.checkin_after_seated_s
                        and now - (t.last_visit_at or t.first_waiter_at) >= r.checkin_quiet_s):
                    t.checkin_at = now
                    t.checkin_done = False
                    self._alert(t, "checkin", now)
            elif t.status == "needs_cleaning":
                if not t.last_alert or now - t.last_alert >= r.cleaning_realert_s:
                    self._alert(t, "cleaning", now)

    # ------------------------------------------------------------ transitions
    def _seat(self, t: Table, at: float, guests: int):
        t.status, t.status_since = "occupied", at
        t.seated_at, t.guests = at, max(1, guests)
        t.first_waiter_at = t.last_visit_at = t.vacated_at = t.last_alert = t.checkin_at = None
        t.checkin_done = False
        t._staff_since = None
        self._push(t, "seated", f"{t.name}: {guests_txt(t.guests)} satte sig", now=at, guests=t.guests)

    def _visit(self, t: Table, now: float, source: str):
        t.last_visit_at = now
        if not t.first_waiter_at:
            t.first_waiter_at = now
            suffix = " (markerat i appen)" if source == "app" else ""
            self._push(t, "waiter", f"{t.name}: servitör på plats efter {mmss(now - t.seated_at)}{suffix}", now=now,
                       response_s=now - t.seated_at)
        elif t.checkin_at and not t.checkin_done:
            t.checkin_done = True
            self._push(t, "waiter", f"{t.name}: servitör var vid bordet", now=now)

    def _leave(self, t: Table, at: float, dishes: bool):
        dur = at - (t.seated_at or at)
        t.status, t.status_since, t.vacated_at = "needs_cleaning", at, at
        t.last_alert = None
        t._max_guests = 0
        self._push(t, "left", f"{t.name}: gästerna har gått", now=at, dining_s=dur, guests=t.guests)
        if not dishes:
            # inget kvar på bordet: räkna som städat direkt
            self._cleaned(t, at, "gästerna har gått, bordet är tomt")
        else:
            self._alert(t, "cleaning", at)

    def _cleaned(self, t: Table, now: float, text: str):
        t.status, t.status_since, t.guests = "free", now, 0
        t._clean_since = None
        self._push(t, "cleaned", f"{t.name}: {text}", now=now,
                   cleaning_s=(now - t.vacated_at) if t.vacated_at else None)

    # ------------------------------------------------------------ manual actions from the app
    def action(self, table_id: str, action: str, now: Optional[float] = None):
        now = self.clock() if now is None else now
        t = self.tables.get(str(table_id))
        if not t:
            return False
        if action == "served" and t.status == "occupied":
            self._visit(t, now, source="app")
        elif action == "cleaned" and t.status == "needs_cleaning":
            self._cleaned(t, now, "städat och redo (markerat i appen)")
        elif action == "free":
            if t.status == "occupied":
                t.vacated_at = now
                self._push(t, "left", f"{t.name}: gästerna har gått (markerat i appen)", now=now,
                           dining_s=now - t.seated_at, guests=t.guests)
            self._cleaned(t, now, "markerat som ledigt")
        elif action == "occupied" and t.status != "occupied":
            self._seat(t, now, min(2, t.seats))
        else:
            return False
        return True

    # ------------------------------------------------------------ state for the app
    def state(self, restaurant: str, cameras: list[dict], party: int = 0, now: Optional[float] = None) -> dict:
        now = self.clock() if now is None else now
        r = self.rules
        out = []
        for t in self.tables.values():
            d = {"id": t.id, "name": t.name, "seats": t.seats, "floor": t.floor, "status": t.status,
                 "guests": t.guests, "attention": None, "waiter_visited": bool(t.first_waiter_at),
                 "waiting_s": None, "response_s": None}
            if t.status == "occupied":
                d["elapsed_s"] = now - t.seated_at
                if not t.first_waiter_at:
                    d["waiting_s"] = now - t.seated_at
                    if d["waiting_s"] >= r.waiter_alert_after_s:
                        d["attention"] = "waiter"
                else:
                    d["response_s"] = t.first_waiter_at - t.seated_at
                    if t.checkin_at and not t.checkin_done:
                        d["attention"] = "checkin"
                        d["quiet_s"] = now - (t.last_visit_at or t.first_waiter_at)
                dine = r.dining_s[bucket(t.guests)]
                d["eta_s"] = max(120, dine - d["elapsed_s"]) + r.cleaning_s
                d["reason"] = "Gästerna har suttit länge" if d["elapsed_s"] > dine else "Gäster äter"
            elif t.status == "needs_cleaning":
                d["elapsed_s"] = now - t.vacated_at
                d["attention"] = "cleaning"
                d["eta_s"] = max(30, r.cleaning_s - d["elapsed_s"])
                d["reason"] = "Ska städas"
            else:
                d["elapsed_s"] = now - t.status_since
                d["eta_s"] = 0
                d["reason"] = "Ledigt nu"
            out.append(d)
        queue = sorted(
            [{"table_id": d["id"], "name": d["name"], "seats": d["seats"], "status": d["status"],
              "eta_s": round(d["eta_s"]), "reason": d["reason"]} for d in out if not party or d["seats"] >= party],
            key=lambda q: (q["eta_s"], q["seats"]))
        return {
            "restaurant": restaurant, "mode": "live", "now": now,
            "rules": {"waiter_alert_after_s": r.waiter_alert_after_s},
            "tables": out,
            "summary": {
                "total": len(out),
                "free": sum(d["status"] == "free" for d in out),
                "occupied": sum(d["status"] == "occupied" for d in out),
                "cleaning": sum(d["status"] == "needs_cleaning" for d in out),
                "attention": sum(bool(d["attention"]) for d in out),
                "guests": sum(d["guests"] for d in out if d["status"] == "occupied"),
            },
            "queue": queue[:8],
            "feed": [{**f, "age_s": now - f["ts"]} for f in self.feed[:25]],
            "cameras": cameras,
        }
