"""Startar Bordvakt: kameror, AI, bordsstatus, push och webbappen.

    python -m bordvakt.main --config config.yaml
"""
from __future__ import annotations

import argparse
import logging
import threading
import time
from types import SimpleNamespace

import uvicorn
import yaml

from .notify import Notifier
from .server import create_app
from .store import Store
from .tracker import Rules, Tracker

log = logging.getLogger("bordvakt")


def build(cfg_path: str):
    with open(cfg_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    rules = Rules(**{k: v for k, v in (cfg.get("rules") or {}).items() if hasattr(Rules, k)})
    store = Store(cfg.get("database", "bordvakt.db"))
    push = cfg.get("push") or {}
    notifier = Notifier(push.get("server", "https://ntfy.sh"), push.get("topic"), push.get("token"))

    def emit(e):
        store.event(e)
        notifier.send(e)
        log.info("%s", e["text"])

    tracker = Tracker(cfg["tables"], rules, emit)
    return SimpleNamespace(cfg=cfg, cfg_path=cfg_path, rules=rules, store=store, tracker=tracker,
                           cameras={}, lock=threading.RLock())


def vision_loop(ctx, fps: float):
    from .vision import Camera, Detector
    v = ctx.cfg.get("vision") or {}
    det = Detector(v.get("model", "yolov8n.pt"), v.get("confidence", 0.35), v.get("standing_ratio", 1.9),
                   v.get("staff_colour_hsv"), v.get("image_size", 640))
    for c in ctx.cfg["cameras"]:
        ctx.cameras[str(c["id"])] = Camera(str(c["id"]), c["url"]).start()
    last_seen = {}
    while True:
        t0 = time.time()
        for cid, cam in ctx.cameras.items():
            frame, ts = cam.latest()
            if frame is None or last_seen.get(cid) == ts:
                continue
            last_seen[cid] = ts
            zones = {str(t["id"]): t["zone"] for t in ctx.cfg["tables"] if str(t.get("camera")) == cid and t.get("zone")}
            if not zones:
                continue
            try:
                obs = det.observe_tables(frame, zones)
            except Exception as ex:
                log.exception("Detektering misslyckades: %s", ex)
                continue
            del frame  # bilden släpps direkt
            with ctx.lock:
                for tid, o in obs.items():
                    ctx.tracker.observe(tid, o)
        time.sleep(max(0.0, 1 / fps - (time.time() - t0)))


def ticker(ctx):
    last_sample = 0.0
    last_purge = 0.0
    while True:
        now = time.time()
        with ctx.lock:
            ctx.tracker.tick(now)
            if now - last_sample >= 60:
                occ = sum(t.status == "occupied" for t in ctx.tracker.tables.values())
                ctx.store.sample(occ, len(ctx.tracker.tables), now)
                last_sample = now
        if now - last_purge > 86400:
            ctx.store.purge(int(ctx.cfg.get("keep_days", 90)))
            last_purge = now
        time.sleep(1)


def main():
    ap = argparse.ArgumentParser(description="Bordvakt")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--fps", type=float, default=2.0, help="analyser per sekund och kamera")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s: %(message)s")
    ctx = build(a.config)
    threading.Thread(target=vision_loop, args=(ctx, a.fps), daemon=True, name="vision").start()
    threading.Thread(target=ticker, args=(ctx,), daemon=True, name="ticker").start()
    log.info("Bordvakt körs: öppna http://<datorns-ip>:%s i mobilen", a.port)
    uvicorn.run(create_app(ctx), host="0.0.0.0", port=a.port, log_level="warning")


if __name__ == "__main__":
    main()
