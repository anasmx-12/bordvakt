"""Bordvakt – AI-bordsövervakning som körs lokalt i restaurangen."""
__version__ = "0.1.0"
