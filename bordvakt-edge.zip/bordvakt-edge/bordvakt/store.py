"""Lokal databas (SQLite). Sparar bara bordshändelser och beläggning per minut – aldrig bild, video eller personer."""
from __future__ import annotations

import sqlite3
import threading
import time
from datetime import datetime

WEEKDAYS = ["Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag", "Söndag"]


class Store:
    def __init__(self, path: str):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.lock = threading.Lock()
        with self.lock:
            self.db.executescript("""
            CREATE TABLE IF NOT EXISTS events(ts REAL, table_id TEXT, type TEXT, kind TEXT, guests INTEGER,
                response_s REAL, dining_s REAL, cleaning_s REAL);
            CREATE TABLE IF NOT EXISTS occupancy(ts REAL, occupied INTEGER, total INTEGER);
            CREATE INDEX IF NOT EXISTS ev_ts ON events(ts);
            CREATE INDEX IF NOT EXISTS oc_ts ON occupancy(ts);
            """)

    def event(self, e: dict):
        with self.lock:
            self.db.execute("INSERT INTO events VALUES(?,?,?,?,?,?,?,?)",
                            (e["ts"], e["table"], e["type"], e.get("kind"), e.get("guests"),
                             e.get("response_s"), e.get("dining_s"), e.get("cleaning_s")))
            self.db.commit()

    def sample(self, occupied: int, total: int, ts: float | None = None):
        with self.lock:
            self.db.execute("INSERT INTO occupancy VALUES(?,?,?)", (ts or time.time(), occupied, total))
            self.db.commit()

    def purge(self, keep_days: int = 90):
        cut = time.time() - keep_days * 86400
        with self.lock:
            self.db.execute("DELETE FROM events WHERE ts<?", (cut,))
            self.db.execute("DELETE FROM occupancy WHERE ts<?", (cut,))
            self.db.commit()

    # ------------------------------------------------------------ veckorapport
    def report(self, days: int, total_tables: int, tables_per_waiter: int, wait_limit_s: int,
               hours=range(11, 23), now: float | None = None) -> dict:
        now = now or time.time()
        since = now - days * 86400
        with self.lock:
            ev = self.db.execute("SELECT ts,type,kind,guests,response_s,cleaning_s FROM events WHERE ts>=?", (since,)).fetchall()
            oc = self.db.execute("SELECT ts,occupied FROM occupancy WHERE ts>=?", (since,)).fetchall()
        hours = list(hours)
        sums = [[0.0] * len(hours) for _ in range(7)]
        cnts = [[0] * len(hours) for _ in range(7)]
        for ts, occ in oc:
            d = datetime.fromtimestamp(ts)
            if d.hour in hours:
                i = hours.index(d.hour)
                sums[d.weekday()][i] += occ
                cnts[d.weekday()][i] += 1
        heat = [[round(sums[w][i] / cnts[w][i], 1) if cnts[w][i] else 0 for i in range(len(hours))] for w in range(7)]
        staffing = [[(-(-min(total_tables, v * 1.15) // tables_per_waiter) if v > 0.2 else 0) for v in row] for row in heat]
        staffing = [[int(x) for x in row] for row in staffing]

        seated = [e for e in ev if e[1] == "seated"]
        resp = [e[4] for e in ev if e[1] == "waiter" and e[4] is not None]
        clean = [e[5] for e in ev if e[1] == "cleaned" and e[5] is not None]
        late = sum(1 for r in resp if r > wait_limit_s)
        late_by_cell: dict[tuple, list] = {}
        for e in ev:
            if e[1] == "waiter" and e[4] is not None:
                d = datetime.fromtimestamp(e[0] - e[4])
                late_by_cell.setdefault((d.weekday(), d.hour), []).append(e[4] > wait_limit_s)

        insights = []
        cells = [(heat[w][i], w, hours[i], staffing[w][i]) for w in range(7) for i in range(len(hours))]
        if any(c[0] for c in cells):
            v, w, h, need = max(cells)
            insights.append(f"Er mest belastade timme är {WEEKDAYS[w].lower()} kl {h}–{h + 1}: i snitt "
                            f"{str(v).replace('.', ',')} av {total_tables} bord upptagna. Planera minst {need} servitörer då.")
        worst = max(((sum(x) / len(x), k) for k, x in late_by_cell.items() if len(x) >= 4), default=None)
        if worst and worst[0] > 0.15:
            (w, h) = worst[1]
            insights.append(f"{WEEKDAYS[w]} kl {h}–{h + 1} väntade {round(worst[0] * 100)} % av sällskapen mer än "
                            f"{wait_limit_s // 60} min på servitör – lägg till en person i det passet.")
        quiet = sum(1 for c in cells if 0 < c[0] < total_tables * 0.2 and c[3] >= 1)
        if quiet:
            insights.append(f"{quiet} timmar i veckan var under 20 % av borden upptagna – där räcker en servitör.")
        if not insights:
            insights.append("För lite data än. Rapporten fylls på efter några serveringar.")

        return {
            "demo": False, "hours": hours, "heatmap": heat, "staffing": staffing, "total_tables": total_tables,
            "tables_per_waiter": tables_per_waiter, "weekdays": WEEKDAYS,
            "kpi": {
                "sessions": len(seated),
                "guests": sum(e[3] or 0 for e in seated),
                "avg_response_s": round(sum(resp) / len(resp)) if resp else None,
                "late_pct": round(late / len(resp) * 100) if resp else 0,
                "avg_cleaning_min": round(sum(clean) / len(clean) / 60, 1) if clean else None,
                "alerts": sum(1 for e in ev if e[1] == "alert"),
            },
            "insights": insights,
        }
