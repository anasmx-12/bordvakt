from bordvakt.tracker import Obs, Rules, Tracker
from bordvakt.store import Store


def make(n=2):
    ev = []
    tr = Tracker([{"id": str(i + 1), "name": f"Bord {i + 1}", "seats": 4} for i in range(n)], Rules(), ev.append,
                 clock=lambda: 0)
    return tr, ev


def run(tr, tid, obs, t0, t1, step=1.0):
    t = t0
    while t <= t1:
        tr.observe(tid, obs, now=t)
        tr.tick(now=t)
        t += step
    return t


def types(ev):
    return [(e["type"], e.get("kind")) for e in ev]


def test_full_cycle_with_alert_visit_leave_clean():
    tr, ev = make()
    run(tr, "1", Obs(guests=3), 0, 30)                      # gäster sätter sig
    assert tr.tables["1"].status == "occupied"
    assert tr.tables["1"].guests == 3
    run(tr, "1", Obs(guests=3), 31, 310)                    # ingen servitör i 5 min
    assert ("alert", "waiter") in types(ev)
    st = tr.state("R", [], now=310)
    assert next(t for t in st["tables"] if t["id"] == "1")["attention"] == "waiter"
    run(tr, "1", Obs(guests=3, staff=True), 311, 315)       # servitör kommer
    assert tr.tables["1"].first_waiter_at is not None
    st = tr.state("R", [], now=316)
    assert next(t for t in st["tables"] if t["id"] == "1")["attention"] is None
    run(tr, "1", Obs(guests=0, dishes=True), 2000, 2070)    # gästerna går, disk kvar
    assert tr.tables["1"].status == "needs_cleaning"
    assert ("alert", "cleaning") in types(ev)
    run(tr, "1", Obs(guests=0, dishes=False), 2071, 2085)   # någon dukar av
    assert tr.tables["1"].status == "free"


def test_brief_passerby_does_not_seat_table():
    tr, ev = make()
    run(tr, "1", Obs(guests=1), 0, 10)
    run(tr, "1", Obs(guests=0), 11, 20)
    assert tr.tables["1"].status == "free"
    assert not ev


def test_short_absence_does_not_end_visit():
    tr, ev = make()
    run(tr, "1", Obs(guests=2), 0, 30)
    run(tr, "1", Obs(guests=0), 31, 60)       # gäst går på toaletten / skymd 30 s
    run(tr, "1", Obs(guests=2), 61, 90)
    assert tr.tables["1"].status == "occupied"
    assert "left" not in [e["type"] for e in ev]


def test_staff_must_stay_to_count():
    tr, _ = make()
    run(tr, "1", Obs(guests=2), 0, 30)
    tr.observe("1", Obs(guests=2, staff=True), now=31)    # går bara förbi
    tr.observe("1", Obs(guests=2, staff=False), now=32)
    assert tr.tables["1"].first_waiter_at is None


def test_app_actions_and_realert():
    tr, ev = make()
    run(tr, "1", Obs(guests=2), 0, 30)
    run(tr, "1", Obs(guests=2), 31, 500)
    assert [e for e in ev if e.get("kind") == "waiter"].__len__() == 2   # larm vid 300 och 480
    assert tr.action("1", "served", now=501)
    assert tr.tables["1"].first_waiter_at == 501
    assert tr.action("1", "free", now=600)
    assert tr.tables["1"].status == "free"


def test_checkin_alert():
    tr, ev = make()
    run(tr, "1", Obs(guests=2), 0, 30)
    run(tr, "1", Obs(guests=2, staff=True), 100, 103)
    run(tr, "1", Obs(guests=2), 104, 2800, step=10)
    assert ("alert", "checkin") in types(ev)
    st = tr.state("R", [], now=2800)
    assert next(t for t in st["tables"] if t["id"] == "1")["attention"] == "checkin"
    tr.action("1", "served", now=2801)
    st = tr.state("R", [], now=2802)
    assert next(t for t in st["tables"] if t["id"] == "1")["attention"] is None


def test_report_from_events(tmp_path):
    s = Store(str(tmp_path / "t.db"))
    tr = Tracker([{"id": "1", "seats": 4}], Rules(), s.event, clock=lambda: 0)
    base = 1_800_000_000.0
    run(tr, "1", Obs(guests=2), base, base + 30)
    run(tr, "1", Obs(guests=2, staff=True), base + 400, base + 404)
    for m in range(0, 120):
        s.sample(1, 1, base + m * 60)
    r = s.report(7, 1, 5, 300, now=base + 7200)
    assert r["kpi"]["sessions"] == 1 and r["kpi"]["guests"] == 2
    assert r["kpi"]["late_pct"] == 100
    assert len(r["heatmap"]) == 7 and r["insights"]
